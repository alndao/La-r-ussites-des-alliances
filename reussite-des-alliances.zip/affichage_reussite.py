def carte_to_chaine(dico):
    val=dico['valeur']
    coul=dico['couleur']
   
    if (coul=='P'):
        coul=chr(9824)
    elif (coul=='C'):
        coul=chr(9825)
    elif (coul=='K'):
        coul=chr(9826)
    elif (coul=='T'):
        coul=chr(9827)
    if (val == 10):
        return (str(10) + coul)
    else :
        return (" " + str(val) + coul)


def afficher_reussite(liste):
    for i in range(len(liste)):
        chaine=carte_to_chaine(liste[i])+" "
        print(chaine, end="")
    print("\n")
    
    


