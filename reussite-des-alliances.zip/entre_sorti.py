def init_pioche_fichier(nom_fichier):
    f=open(nom_fichier)
    Liste=[]
    liste_lignes=f.readlines()
    for ligne in liste_lignes:
        L=ligne.split(" ")
        for elem in L :
            dico={}
            elem=elem.split("-")
            if len(elem)==2:
                if elem[0]=="V" or elem[0]=="D" or elem[0]=="R" or elem[0]=="A":
                    dico["valeur"]=elem[0]
                else :
                    dico["valeur"]=int(elem[0])
                dico["couleur"]=elem[1]
                Liste.append(dico)

    f.close()
    return Liste


def ecrire_fichier_reussite(nom_fich, liste):
    f=open(nom_fich,'w')
    for carte in liste:
        f.write(str(carte["valeur"])+"-"+carte["couleur"]+" ")
    f.close()

#liste=[{'valeur': 'V', 'couleur': 'C'}, {'valeur': 8, 'couleur': 'P'}, {'valeur': 'V', 'couleur': 'K'}, {'valeur': 'A', 'couleur': 'C'}, {'valeur': 10, 'couleur': 'P'}]
#ecrire_fichier_reussite("data2.txt", liste)



