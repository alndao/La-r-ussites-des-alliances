def carte_to_chaine(dico):
    val=dico['valeur']
    coul=dico['couleur']
   
    if (coul=='P'):
        coul=chr(9824)
    elif (coul=='C'):
        coul=chr(9825)
    elif (coul=='K'):
        coul=chr(9826)
    elif (coul=='T'):
        coul=chr(9827)
    if (val == 10):
        return (str(10) + coul)
    else :
        return (" " + str(val) + coul)


def afficher_reussite(liste):
    for i in range(len(liste)):
        chaine=carte_to_chaine(liste[i])+" "
        print(chaine, end="")
    print("\n")
    
import random

def init_pioche_alea(nb_cartes=32):
    liste_32_cartes=[{"valeur":7, "couleur":"T"}, {"valeur":8, "couleur":"T"}, {"valeur":9, "couleur":"T"}, {"valeur":10, "couleur":"T"}, {"valeur":"V", "couleur":"T"},{"valeur":"D", "couleur":"T"}, {"valeur":"R", "couleur":"T"}, {"valeur":"A", "couleur":"T"}, {"valeur":7, "couleur":"P"}, {"valeur":8, "couleur":"P"}, {"valeur":9, "couleur":"P"}, {"valeur":10, "couleur":"P"}, {"valeur":"V", "couleur":"P"},{"valeur":"D", "couleur":"P"}, {"valeur":"R", "couleur":"P"}, {"valeur":"A", "couleur":"P"}, {"valeur":7, "couleur":"C"}, {"valeur":8, "couleur":"C"},{"valeur":9, "couleur":"C"}, {"valeur":10, "couleur":"C"}, {"valeur":"V", "couleur":"C"},{"valeur":"D", "couleur":"C"}, {"valeur":"R", "couleur":"C"}, {"valeur":"A", "couleur":"C"}, {"valeur":7, "couleur":"K"}, {"valeur":8, "couleur":"K"}, {"valeur":9, "couleur":"K"}, {"valeur":10, "couleur":"K"}, {"valeur":"V", "couleur":"K"},{"valeur":"D", "couleur":"K"}, {"valeur":"R", "couleur":"K"}, {"valeur":"A", "couleur":"K"}]
    liste_52_cartes=[{"valeur":2, "couleur":"T"}, {"valeur":3, "couleur":"T"}, {"valeur":4, "couleur":"T"}, {"valeur":5, "couleur":"T"}, {"valeur":6, "couleur":"T"}, {"valeur":7, "couleur":"T"}, {"valeur":8, "couleur":"T"}, {"valeur":9, "couleur":"T"}, {"valeur":10, "couleur":"T"}, {"valeur":"V", "couleur":"T"},{"valeur":"D", "couleur":"T"}, {"valeur":"R", "couleur":"T"}, {"valeur":"A", "couleur":"T"}, {"valeur":2, "couleur":"P"}, {"valeur":3, "couleur":"P"}, {"valeur":4, "couleur":"P"}, {"valeur":5, "couleur":"P"}, {"valeur":6, "couleur":"P"}, {"valeur":7, "couleur":"P"}, {"valeur":8, "couleur":"P"}, {"valeur":9, "couleur":"P"}, {"valeur":10, "couleur":"P"}, {"valeur":"V", "couleur":"P"},{"valeur":"D", "couleur":"P"}, {"valeur":"R", "couleur":"P"}, {"valeur":"A", "couleur":"P"}, {"valeur":2, "couleur":"C"}, {"valeur":3, "couleur":"C"}, {"valeur":4, "couleur":"C"}, {"valeur":5, "couleur":"C"}, {"valeur":6, "couleur":"C"}, {"valeur":7, "couleur":"C"}, {"valeur":8, "couleur":"C"},{"valeur":9, "couleur":"C"}, {"valeur":10, "couleur":"C"}, {"valeur":"V", "couleur":"C"},{"valeur":"D", "couleur":"C"}, {"valeur":"R", "couleur":"C"}, {"valeur":"A", "couleur":"C"}, {"valeur":2, "couleur":"K"}, {"valeur":3, "couleur":"K"}, {"valeur":4, "couleur":"K"}, {"valeur":5, "couleur":"K"}, {"valeur":6, "couleur":"K"}, {"valeur":7, "couleur":"K"}, {"valeur":8, "couleur":"K"}, {"valeur":9, "couleur":"K"}, {"valeur":10, "couleur":"K"}, {"valeur":"V", "couleur":"K"},{"valeur":"D", "couleur":"K"}, {"valeur":"R", "couleur":"K"}, {"valeur":"A", "couleur":"K"}]            
    if nb_cartes==32:
        random.shuffle(liste_32_cartes)
        return liste_32_cartes
    if nb_cartes==52:
        liste=random.shuffle(liste_52_cartes)
        return liste_52_cartes

def verifier_pioche(pioche, nb_cartes=32):
    if len(pioche) != nb_cartes:
        return False
    else:
        for i in range(nb_cartes):
            for j in range(i+1, nb_cartes):
                if nb_cartes==32:
                    if pioche[j]["valeur"]==2 or pioche[j]["valeur"]==3 or pioche[j]["valeur"]==4 or pioche[j]["valeur"]==5 or pioche[j]["valeur"]==6 :
                        return False
                if pioche[i]==pioche[j]:
                    return False
    return True

        


def alliance(carte1, carte2):
    alliances=False
    if carte1['valeur']==carte2['valeur'] or carte1['couleur']==carte2['couleur']:
        return True
    return alliances


carte1={"valeur":7, "couleur":"P"}
carte2={"valeur":8, "couleur":"C"}

#print(alliance(cate1, carte2))


def saut_si_possible(liste_tas, num_tas):                         
    saut=False
    if 1 <= num_tas <= len(liste_tas)-2: # Par prudence précisons que num_tas doit etre au minimum égale au troisième element de la liste
                                                                    # pour qu'on puisse parler de réussite
        if alliance(liste_tas[num_tas-1], liste_tas[num_tas+1]):
            liste_tas.pop(num_tas-1) 
            saut=True
    return saut


#liste=[{"valeur":7, "couleur":"T"}, {"valeur":8, "couleur":"P"}, {"valeur":7, "couleur":"C"}]
#print(saut_si_possible(liste, 1))

def autre_saut_si_possible(liste_tas, affiche1=False):
    n=len(liste_tas)                                            # fonction auxilière qui prend en argument une liste de tas et un bouléen valant False par defaut
    j=0
    i=0
    while i < 2*n :
        while j < len(liste_tas):                                  # cette fonction vérifie si un saut est possible dans la liste de tas
            if saut_si_possible(liste_tas, j) :                 # si le saut est possible la fonction l'effectue 
                if affiche1:                                  # a chaque saut la fonction affiche l'etape de la réussite si affiche vaut True.
                    afficher_reussite(liste_tas)
                j = -1
            j += 1
        j = 0
        i += 1
    
liste_tas=[{"valeur":10, "couleur":"P"}, {"valeur":7, "couleur":"K"}, {"valeur":"D", "couleur":"P"}, {"valeur":7, "couleur":"K"}, {"valeur":8, "couleur":"P"}]
#autre_saut_si_possible(liste_tas)

def une_etape_reussite(liste_tas, pioche, affiche=False):
    liste_tas.append(pioche[0])
    if affiche:
        afficher_reussite(liste_tas)
    pioche.pop(0)
    num_tas=len(liste_tas)-2
    if saut_si_possible(liste_tas, num_tas):
        if affiche:
            afficher_reussite(liste_tas)
        autre_saut_si_possible(liste_tas, affiche1=affiche)    


    
def reussite_mode_auto(pioche, affiche=False):
    copi_pioche=list(pioche)
    liste_tas=[]
    if affiche:
        afficher_reussite(copi_pioche)
    while len(copi_pioche) > 0:
        une_etape_reussite(liste_tas, copi_pioche, affiche=affiche)
    return liste_tas

def reussite_mode_manuel(pioche, nb_tas_max=2):
    copi_pioche=list(pioche)
    liste_tas=[]
    for i in range(3):
        liste_tas.append(copi_pioche[i])
        copi_pioche.pop(i)
    while len(copi_pioche) > 0:
        for i in range(len(liste_tas)-1):
            if i >= 10:
                print(i," ",end="")
            else:
                print("",i, " ", end="")
        print("",len(liste_tas)-1)
        afficher_reussite(liste_tas)
        print("C'est à vous de jouer")
        print("p = Piocher une autre carte")
        print("s = Faire un saut")
        print("q = Quitter la partie")
        choix=input("Choisissez: ")
        if choix=="p":
            liste_tas.append(copi_pioche[0])
            copi_pioche.pop(0)
            print("\n")
        elif choix=="s":
            reponse=int(input("Quel est le numero de tas à faire sauter? "))
            if saut_si_possible(liste_tas, reponse):
                print("Bravo!")
            else:
                print("Le saut est impossible.")
            print("\n")
        elif choix=="q":
            for j in range(len(copi_pioche)):
                liste_tas.append(copi_pioche[j])
            copi_pioche=[]
            print("\n")
        else:
            print("Concentrez-vous ! Votre choix n'existe pas")
            print("Veuillez choisir parmi les choix proposez")
            print("\n")
                        
    if len(liste_tas) <= nb_tas_max:
        afficher_reussite(liste_tas)
        print("Felicitations !!! Vous avez gagné la partie")
    else:
        print("Domage. Vous avez perdu")
        afficher_reussite(liste_tas)
    return liste_tas
    

def lance_reussite(mode, nb_cartes=32, affiche=False, nb_tas_max=2):
    pioche=init_pioche_alea(nb_cartes=nb_cartes)
    if verifier_pioche(pioche):
        if mode=="auto":
            reussite_mode_auto(pioche, affiche=affiche)
        elif mode=="manuel":
            reussite_mode_manuel(pioche, nb_tas_max=nb_tas_max)

        
lance_reussite("manuel", nb_cartes=32, affiche=True, nb_tas_max=2)
 
        
        

