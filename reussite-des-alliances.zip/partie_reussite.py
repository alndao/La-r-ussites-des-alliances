def reussite_mode_auto(pioche, affiche=False):
    copi_pioche=list(pioche)
    liste_tas=[]
    if affiche:
        afficher_reussite(copi_pioche)
    while len(copi_pioche) != []:
        une_etape_reussite(liste_tas, copi_pioche, affiche=affiche)
    return liste_tas


pioche=init_pioche_alea()
#print(reussite_mode_auto(pioche, affiche=True))


def reussite_mode_manuel(pioche, nb_tas_max=2):
    copi_pioche=list(pioche)
    liste_tas=[]
    for i in range(3):
        liste_tas.append(copi_pioche[i])
        copi_pioche.pop(i)
    while len(copi_pioche) > 0:
        for i in range(len(liste_tas)-1):
            if i >= 10:
                print(i," ",end="")
            else:
                print("",i, " ", end="")
        print("",len(liste_tas)-1)
        afficher_reussite(liste_tas)
        print("C'est à vous de jouer")
        print("p = Piocher une autre carte")
        print("s = Faire un saut")
        print("q = Quitter la partie")
        choix=input("Choisissez: ")
        if choix=="p":
            liste_tas.append(copi_pioche[0])
            copi_pioche.pop(0)
            print("\n")
        elif choix=="s":
            reponse=int(input("Quel est le numero de tas à faire sauter? "))
            if saut_si_possible(liste_tas, reponse):
                print("Bravo!")
            else:
                print("Le saut est impossible.")
            print("\n")
        elif choix=="q":
            for j in range(len(copi_pioche)):
                liste_tas.append(copi_pioche[j])
            copi_pioche=[]
            print("\n")
        else:
            print("Concentrez-vous ! Votre choix n'existe pas")
            print("Veuillez choisir parmi les choix proposez")
            print("\n")
                        
    if len(liste_tas) <= nb_tas_max:
        afficher_reussite(liste_tas)
        print("Felicitations !!! Vous avez gagné la partie")
    else:
        print("Domage. Vous avez perdu")
        afficher_reussite(liste_tas)
    return liste_tas
    
        
pioche=init_pioche_alea()
#reussite_mode_manuel(pioche, nb_tas_max=2)

def lance_reussite(mode, nb_cartes=32, affiche=False, nb_tas_max=2):
    pioche=init_pioche_alea()
    if mode=="auto":
        reussite_mode_auto(pioche, affiche=affiche)
    elif mode=="manuel":
        reussite_mode_manuel(pioche, nb_tas_max=nb_tas_max)

        

   
        
        
