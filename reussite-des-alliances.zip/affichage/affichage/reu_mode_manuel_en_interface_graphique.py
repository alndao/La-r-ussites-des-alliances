#partie1
def carte_to_chaine(dico):
    val=dico['valeur']
    coul=dico['couleur']
   
    if (coul=='P'):
        coul=chr(9824)
    elif (coul=='C'):
        coul=chr(9825)
    elif (coul=='K'):
        coul=chr(9826)
    elif (coul=='T'):
        coul=chr(9827)
    if (val == 10):
        return (str(10) + coul)
    else :
        return (" " + str(val) + coul)


def afficher_reussite(liste):
    for i in range(len(liste)):
        chaine=carte_to_chaine(liste[i])+" "
        print(chaine, end="")
    print("\n")

#partie2
def init_pioche_fichier(nom_fichier):
    f=open(nom_fichier)
    Liste=[]
    liste_lignes=f.readlines()
    for ligne in liste_lignes:
        L=ligne.split(" ")
        for elem in L :
            dico={}
            elem=elem.split("-")
            if len(elem)==2:
                if elem[0]=="V" or elem[0]=="D" or elem[0]=="R" or elem[0]=="A":
                    dico["valeur"]=elem[0]
                else :
                    dico["valeur"]=int(elem[0])
                dico["couleur"]=elem[1]
                Liste.append(dico)

    f.close()
    return Liste


def ecrire_fichier_reussite(nom_fich, liste):
    f=open(nom_fich,'w')
    for carte in liste:
        f.write(str(carte["valeur"])+"-"+carte["couleur"]+" ")
    f.close()

#partie3
import random

def init_pioche_alea(nb_cartes=32):
    liste_32_cartes=[{"valeur":7, "couleur":"T"}, {"valeur":8, "couleur":"T"}, {"valeur":9, "couleur":"T"}, {"valeur":10, "couleur":"T"}, {"valeur":"V", "couleur":"T"},{"valeur":"D", "couleur":"T"}, {"valeur":"R", "couleur":"T"}, {"valeur":"A", "couleur":"T"}, {"valeur":7, "couleur":"P"}, {"valeur":8, "couleur":"P"}, {"valeur":9, "couleur":"P"}, {"valeur":10, "couleur":"P"}, {"valeur":"V", "couleur":"P"},{"valeur":"D", "couleur":"P"}, {"valeur":"R", "couleur":"P"}, {"valeur":"A", "couleur":"P"}, {"valeur":7, "couleur":"C"}, {"valeur":8, "couleur":"C"},{"valeur":9, "couleur":"C"}, {"valeur":10, "couleur":"C"}, {"valeur":"V", "couleur":"C"},{"valeur":"D", "couleur":"C"}, {"valeur":"R", "couleur":"C"}, {"valeur":"A", "couleur":"C"}, {"valeur":7, "couleur":"K"}, {"valeur":8, "couleur":"K"}, {"valeur":9, "couleur":"K"}, {"valeur":10, "couleur":"K"}, {"valeur":"V", "couleur":"K"},{"valeur":"D", "couleur":"K"}, {"valeur":"R", "couleur":"K"}, {"valeur":"A", "couleur":"K"}]
    liste_52_cartes=[{"valeur":2, "couleur":"T"}, {"valeur":3, "couleur":"T"}, {"valeur":4, "couleur":"T"}, {"valeur":5, "couleur":"T"}, {"valeur":6, "couleur":"T"}, {"valeur":7, "couleur":"T"}, {"valeur":8, "couleur":"T"}, {"valeur":9, "couleur":"T"}, {"valeur":10, "couleur":"T"}, {"valeur":"V", "couleur":"T"},{"valeur":"D", "couleur":"T"}, {"valeur":"R", "couleur":"T"}, {"valeur":"A", "couleur":"T"}, {"valeur":2, "couleur":"P"}, {"valeur":3, "couleur":"P"}, {"valeur":4, "couleur":"P"}, {"valeur":5, "couleur":"P"}, {"valeur":6, "couleur":"P"}, {"valeur":7, "couleur":"P"}, {"valeur":8, "couleur":"P"}, {"valeur":9, "couleur":"P"}, {"valeur":10, "couleur":"P"}, {"valeur":"V", "couleur":"P"},{"valeur":"D", "couleur":"P"}, {"valeur":"R", "couleur":"P"}, {"valeur":"A", "couleur":"P"}, {"valeur":2, "couleur":"C"}, {"valeur":3, "couleur":"C"}, {"valeur":4, "couleur":"C"}, {"valeur":5, "couleur":"C"}, {"valeur":6, "couleur":"C"}, {"valeur":7, "couleur":"C"}, {"valeur":8, "couleur":"C"},{"valeur":9, "couleur":"C"}, {"valeur":10, "couleur":"C"}, {"valeur":"V", "couleur":"C"},{"valeur":"D", "couleur":"C"}, {"valeur":"R", "couleur":"C"}, {"valeur":"A", "couleur":"C"}, {"valeur":2, "couleur":"K"}, {"valeur":3, "couleur":"K"}, {"valeur":4, "couleur":"K"}, {"valeur":5, "couleur":"K"}, {"valeur":6, "couleur":"K"}, {"valeur":7, "couleur":"K"}, {"valeur":8, "couleur":"K"}, {"valeur":9, "couleur":"K"}, {"valeur":10, "couleur":"K"}, {"valeur":"V", "couleur":"K"},{"valeur":"D", "couleur":"K"}, {"valeur":"R", "couleur":"K"}, {"valeur":"A", "couleur":"K"}]            
    if nb_cartes==32:
        random.shuffle(liste_32_cartes)
        return liste_32_cartes
    if nb_cartes==52:
        liste=random.shuffle(liste_52_cartes)
        return liste_52_cartes

#liste=init_pioche_alea(nb_cartes=32)
#ecrire_fichier_reussite("fichier.txt", liste)
#print(init_pioche_fichier("fichier.txt"))
        
#partie4
def alliance(carte1, carte2):
    alliances=False
    if carte1['valeur']==carte2['valeur'] or carte1['couleur']==carte2['couleur']:
        return True
    return alliances


carte1={"valeur":7, "couleur":"P"}
carte2={"valeur":8, "couleur":"C"}

def saut_si_possible(liste_tas, num_tas):                         
    saut=False
    if 1 <= num_tas <= len(liste_tas)-2: # Par prudence précisons que num_tas doit etre au minimum égale au troisième element de la liste
                                                                    # pour qu'on puisse parler de réussite
        if alliance(liste_tas[num_tas-1], liste_tas[num_tas+1]):
            liste_tas.pop(num_tas-1) 
            saut=True
    return saut

def autre_saut_si_possible(liste_tas, affiche1=False):
    n=len(liste_tas)                                            # fonction auxilière qui prend en argument une liste de tas et un bouléen valant False par defaut
    j=0
    i=0
    while i < 2*n :
        while j < len(liste_tas):                                  # cette fonction vérifie si un saut est possible dans la liste de tas
            if saut_si_possible(liste_tas, j) :                 # si le saut est possible la fonction l'effectue 
                if affiche1:                                  # a chaque saut la fonction affiche l'etape de la réussite si affiche vaut True.
                    afficher_reussite(liste_tas)
                j = -1
            j += 1
        j = 0
        i += 1
    
def une_etape_reussite(liste_tas, pioche, affiche=False):
    liste_tas.append(pioche[0])
    if affiche:
        afficher_reussite(liste_tas)
    pioche.pop(0)
    num_tas=len(liste_tas)-2
    if saut_si_possible(liste_tas, num_tas):
        if affiche:
            afficher_reussite(liste_tas)
        autre_saut_si_possible(liste_tas, affiche1=affiche)

#parite5
def reussite_mode_auto(pioche, affiche=False):
    copi_pioche=list(pioche)
    liste_tas=[]
    if affiche:
        afficher_reussite(copi_pioche)
    while len(copi_pioche) > 0:
        une_etape_reussite(liste_tas, copi_pioche, affiche=affiche)
    return liste_tas


def reussite_mode_manuel(pioche, nb_tas_max=2):
    copi_pioche=list(pioche)
    liste_tas=[]
    for i in range(3):
        liste_tas.append(copi_pioche[i])
        copi_pioche.pop(i)
    while len(copi_pioche) > 0:
        for i in range(len(liste_tas)-1):
            if i >= 10:
                print(i," ",end="")
            else:
                print("",i, " ", end="")
        print("",len(liste_tas)-1)
        afficher_reussite(liste_tas)
        print("C'est à vous de jouer")
        print("p = Piocher une autre carte")
        print("s = Faire un saut")
        print("q = Quitter la partie")
        choix=input("Choisissez: ")
        if choix=="p":
            liste_tas.append(copi_pioche[0])
            copi_pioche.pop(0)
            print("\n")
        elif choix=="s":
            reponse=int(input("Quel est le numero de tas à faire sauter? "))
            if saut_si_possible(liste_tas, reponse):
                print("Bravo!")
            else:
                print("Le saut est impossible.")
            print("\n")
        elif choix=="q":
            for j in range(len(copi_pioche)):
                liste_tas.append(copi_pioche[j])
            copi_pioche=[]
            print("\n")
        else:
            print("Concentrez-vous ! Votre choix n'existe pas")
            print("Veuillez choisir parmi les choix proposez")
            print("\n")
                        
    if len(liste_tas) <= nb_tas_max:
        afficher_reussite(liste_tas)
        print("Felicitations !!! Vous avez gagné la partie")
    else:
        print("Domage. Vous avez perdu")
        afficher_reussite(liste_tas)
    return liste_tas
    
def lance_reussite(mode, nb_cartes=32, affiche=False, nb_tas_max=2):
    pioche=init_pioche_alea()
    if mode=="auto":
        reussite_mode_auto(pioche, affiche=affiche)
    elif mode=="manuel":
        reussite_mode_manuel(pioche, nb_tas_max=nb_tas_max)
#partie6
def verifier_pioche(pioche, nb_cartes=32):
    if len(pioche) != nb_cartes:
        return False
    else:
        j=0
        for i in range(nb_cartes):
            carte_precedente=pioche[i]
            while j < nb_cartes:
                if carte_precedente==pioche[j]:
                    return False
                    j += 1
    return True
#extension
def res_multi_simulation(nb_sim, nb_cartes=32):
    liste_nombre_tas=[]
    for i in range(nb_sim):
        if nb_cartes==32:
            pioche=init_pioche_alea()
        elif nb_cartes==52:
            pioche=inti_pioche_alea(nb_cartes=52)
        liste_tas_finale=reussite_mode_auto(pioche, affiche=False)
        liste_nombre_tas.append(len(liste_tas_finale))
    return liste_nombre_tas

def statistiques_nb_tas(nb_sim, nb_cartes=32):
    liste_nombre_tas=res_multi_simulation(nb_sim, nb_cartes=nb_cartes)
    maxi=liste_nombre_tas[0]
    mini=liste_nombre_tas[0]
    somme=0
    for i in range(1, len(liste_nombre_tas)):
        if maxi < liste_nombre_tas[i]:
            maxi=liste_nombre_tas[i]
        if mini > liste_nombre_tas[i]:
            mini=liste_nombre_tas[i]
        somme += liste_nombre_tas[i]
    print("La moyenne des tas obtenu sur", nb_sim, "reussites automatiques est: ",somme/(len(liste_nombre_tas)))
    print("Le nombre de tas minimum sur", nb_sim, "reussites automatiques est: ", mini)
    print("Le nombre de tas maximum sur", nb_sim, "reussites automatiques est: ", maxi)

#statistiques_nb_tas(7, nb_cartes=32)


def res_multi_simulation(nb_sim, nb_cartes=32):
    liste_nombre_tas=[]
    for i in range(nb_sim):
        if nb_cartes==32:
            pioche=init_pioche_alea()
        elif nb_cartes==52:
            pioche=inti_pioche_alea(nb_cartes=52)
        liste_tas_finale=reussite_mode_auto(pioche, affiche=False)
        liste_nombre_tas.append(len(liste_tas_finale))
    return liste_nombre_tas

def statistiques_nb_tas(nb_sim, nb_cartes=32):
    liste_nombre_tas=res_multi_simulation(nb_sim, nb_cartes=nb_cartes)
    maxi=liste_nombre_tas[0]
    mini=liste_nombre_tas[0]
    somme=0
    for i in range(1, len(liste_nombre_tas)):
        if maxi < liste_nombre_tas[i]:
            maxi=liste_nombre_tas[i]
        if mini > liste_nombre_tas[i]:
            mini=liste_nombre_tas[i]
        somme += liste_nombre_tas[i]
    print("La moyenne des tas obtenu sur", nb_sim, "reussites automatiques est: ",somme/(len(liste_nombre_tas)))
    print("Le nombre de tas minimum sur", nb_sim, "reussites automatiques est: ", mini)
    print("Le nombre de tas maximum sur", nb_sim, "reussites automatiques est: ", maxi)

#statistiques_nb_tas(3, nb_cartes=32)



def estim_Probabilite(nb_sim, nb_cartes=32):
    listes_des_proba=[]
    nb_tas_max=2
    for j in range(32):
        liste=res_multi_simulation(nb_sim, nb_cartes=nb_cartes)
        frequence=0
        for i in range(len(liste)):
            if liste[i] <= nb_tas_max: 
                frequence += 1
        proba=frequence/(len(liste))
        listes_des_proba.append(proba)
        nb_tas_max += 1
    return listes_des_proba

#print(estim_Probabilite(20, nb_cartes=32))

'''
from pylab import*
import matplotlib.pyplot as plt
import numpy as np
plt.clf()
x=np.linspace(2, 32, 1000)
y=2*x
plt.plot(x,y)
plt.show()
#estim_Probabilite(20, nb_cartes=32)
'''
# interface graphique 

#!/usr/bin/env python3

from random import choice
from turtle import *

def saut_si_possible_version2(liste_tas, num_tas):                         
    saut=False
    if 1 <= num_tas <= len(liste_tas)-2:                                                                  
        if alliance(liste_tas[num_tas-1], liste_tas[num_tas+1]):
            saut=True
    return saut

def autre_saut_si_possible_version2(liste_tas):
    n=len(liste_tas)                                            
    j=0
    i=0
    liste=[]
    while i < 2*n :
        while j < len(liste_tas):                                  
            if saut_si_possible(liste_tas, j) :                  
                liste.append(j)
                j = -1
            j += 1
        j = 0
        i += 1
    return liste

liste1=liste=[{"valeur":6, "couleur":"T"}, {"valeur":8, "couleur":"K"}, {"valeur":7, "couleur":"P"},{"valeur":10, "couleur":"K"},{"valeur":"A", "couleur":"T"}]
#print(autre_saut_si_possible_version2(liste1))
    
def reussite_mode_auto_en_interface_graphique(liste_carte):
    fenetre = Screen()  # la fenetre d'affichage
    setup(width=1366, height=768, startx=0, starty=0)
    title("La reussite des alliances")
    bgpic("photo.gif")
    bgcolor("dark blue")
    valeurs=[]
    couleurs=[]
    
    for carte in liste_carte:
        valeurs.append(str(carte["valeur"]))
        couleurs.append(carte["couleur"])
    
    carte = {}
    for c in couleurs:
        for v in valeurs:
            fichier = "imgs/carte-" + v + '-' + c + '.gif'
            carte[c, v] = fichier
            fenetre.register_shape( fichier ) # nouvelle forme pour le pointeur

    # On charge aussi l'image du dos des cartes
    dos = "imgs/carte-dos.gif"
    fenetre.register_shape( dos )
    # coordonnées de démarrage

    xinit = -650
    yinit =  200

    largeur_carte = 44
    hauteur_carte = 64
    separation = 5      # espace à laisser entre les cartes


    up()          # on ne trace pas les déplacement
    speed(3)      # changer la vitesse d'affichage 0-10

    tampons = {}  # dictionnaire pour se souvenir où on a placé les cartes

    pioche=list(liste_carte)
    liste_tas=[]
    
    while pioche != []:
        liste_tas.append(pioche[0])
        pioche.pop(0)
        elem=liste_tas[-1]
        
        shape( dos )

        goto(xinit,yinit)
        c=elem["couleur"]
        v=str(elem["valeur"])
        shape( carte[ c, v] )
        tampons[c, v]=stamp()
    

        hideturtle() 

        #print (tampons)
        
        num_tas=len(liste_tas)-2
        if saut_si_possible_version2(liste_tas, num_tas):
            
            elem=liste_tas[num_tas-1]
            c=elem["couleur"]
            v=str(elem["valeur"])
            clearstamp (tampons[c, v])
            tampons.pop ((c, v))
            tas_a_supprimer=num_tas-1
            liste_tas.pop(num_tas-1)
            
              
            clearstamps(-2) # on fait sauter la carte d'indice num_tas et on décale toutes situant à sa droite ers la gauche
            
           
            xinit=xprecedent - largeur_carte - separation
            yinit=yprecedent

            if tas_a_supprimer == 26:
                yinit = yprecedent + hauteur_carte + separation
                xinit=xperso 
                
            
            for i in range(num_tas-1, len(liste_tas)):
                shape( dos )
                elem1=liste_tas[i]
                c1=elem1["couleur"]
                v1=str(elem1["valeur"])
                goto(xinit,yinit)
                shape( carte[ c1, v1] )
                tampons[c1, v1]=stamp()

                if i != len(liste_tas)-1:                
                    xinit = xinit + largeur_carte + separation

                if xinit > 650:  # essentiel
                    xinit=-650
                    yinit = yinit - hauteur_carte - separation

            
        # Verifions si d'autres sauts sont possibles
            
            copi_liste_tas = list(liste_tas)           # pour eviter que la fonction autre saut si possible modifient ma liste_tas
            liste_tas_a_sauter=autre_saut_si_possible_version2(copi_liste_tas)
            #print(liste_tas_a_sauter)
            
            if liste_tas_a_sauter != []:
                
                for num_tas in liste_tas_a_sauter:
                    
                    if saut_si_possible_version2(liste_tas, num_tas):
            
                        elem=liste_tas[num_tas-1]
                        c=elem["couleur"]
                        v=str(elem["valeur"])
                        clearstamp (tampons[c, v])
                        tampons.pop ((c, v))
                        tas_a_supprimer=num_tas-1
                        liste_tas.pop(num_tas-1)

                        
                        clearstamps(-(len(liste_tas)-num_tas+1)) #-3 on fait sauter la carte d'indice num_tas et on décale toutes situant à sa droite ers la gauche
                        #print(len(liste_tas)-num_tas+1)

                        if tas_a_supprimer == 26 :
                            yinit=yinit + hauteur_carte + separation
                            
                        if num_tas > 26:
                            num_tas=num_tas-26
                            
                        xinit=xinit -(len(liste_tas)-num_tas+1)*largeur_carte -(len(liste_tas)-num_tas+1)*separation

                       
                        for i in range(num_tas-1, len(liste_tas)):
                            shape( dos )
                            elem1=liste_tas[i]
                            c1=elem1["couleur"]
                            v1=str(elem1["valeur"])
                            goto(xinit,yinit)
                            shape( carte[ c1, v1] )
                            tampons[c1, v1]=stamp()
                    
                            if i != len(liste_tas)-1:                
                                xinit = xinit + largeur_carte + separation
                
            liste_tas_a_sauter=[]
                  
       
        xprecedent=xinit
        yprecedent=yinit

        if num_tas == 25:
            xperso=xinit
        
        xinit = xinit + largeur_carte + separation
        
        if xinit > 650:
            xinit=-650
            yinit = yinit - hauteur_carte - separation
        
    goto(0, 0)
    write("CLIQUER DANS LA FENETRE POUR TERMINER ", align='center')
    exitonclick()

# interface 2   ============================== #


def reussite_mode_manuel_en_interface_graphique(pioche, nb_tas_max):
    fenetre = Screen()  # la fenetre d'affichage
    setup(width=1366, height=768, startx=0, starty=0)
    title("La reussite des alliances")
    bgcolor("dark blue")
    # charger les images de toutes les cartes de la pioche
    valeurs=[]
    couleurs=[]
    
    for carte in pioche:
        valeurs.append(str(carte["valeur"]))
        couleurs.append(carte["couleur"])
    
    carte = {}
    for c in couleurs:
        for v in valeurs:
            fichier = "imgs/carte-" + v + '-' + c + '.gif'
            carte[c, v] = fichier
            fenetre.register_shape( fichier ) # nouvelle forme pour le pointeur

    # On charge aussi l'image du dos des cartes
    dos = "imgs/carte-dos.gif"
    fenetre.register_shape( dos )
    # coordonnées de démarrage

    xinit = -650
    yinit =  200

    largeur_carte = 44
    hauteur_carte = 64
    separation = 5      # espace à laisser entre les cartes



    up()          # on ne trace pas les déplacement
    speed(3)      # changer la vitesse d'affichage 0-10

    tampons = {}  # dictionnaire pour se souvenir où on a placé les cartes
 
# ==================================================
    copi_pioche=list(pioche)
    liste_tas=[]
    for i in range(3):
        liste_tas.append(copi_pioche[i])
        copi_pioche.pop(i)
        elem=liste_tas[-1]
        
        shape( dos )

        goto(xinit,yinit)
        c=elem["couleur"]
        v=str(elem["valeur"])
        shape( carte[ c, v] )
        tampons[c, v]=stamp()

        xinit = xinit + largeur_carte + separation

        hideturtle() 
    x = -650
    y = -150
    for elem in copi_pioche:

        shape( dos )

        goto(x,y)
        c=elem["couleur"]
        v=str(elem["valeur"])
        shape( carte[ c, v] )
        tampons[c, v]=stamp()

        y = y - 1

    
    while len(copi_pioche) != []:
    
            liste_tas.append(copi_pioche[0])
            copi_pioche.pop(0)
            elem=liste_tas[-1]
        
            shape( dos )

            goto(xinit,yinit)
            c=elem["couleur"]
            v=str(elem["valeur"])
            shape( carte[ c, v] )
            tampons[c, v]=stamp()
    
    
    
       
liste=init_pioche_alea()
reussite_mode_manuel_en_interface_graphique(liste, nb_tas_max=2)
        
        

              
        
        print("C'est à vous de jouer")
        print("p = Piocher une autre carte")
        print("s = Faire un saut")
        print("q = Quitter la partie")
        choix=input("Choisissez: ")
        if choix=="p":
            liste_tas.append(copi_pioche[0])
            copi_pioche.pop(0)
            print("\n")
        elif choix=="s":
            reponse=int(input("Quel est le numero de tas à faire sauter? "))
            if saut_si_possible(liste_tas, reponse):
                print("Bravo!")
            else:
                print("Le saut est impossible.")
            print("\n")
        elif choix=="q":
            for j in range(len(copi_pioche)):
                liste_tas.append(copi_pioche[j])
            copi_pioche=[]
            print("\n")
        else:
            print("Concentrez-vous ! Votre choix n'existe pas")
            print("Veuillez choisir parmi les choix proposez")
            print("\n")
                        
    if len(liste_tas) <= nb_tas_max:
        afficher_reussite(liste_tas)
        print("Felicitations !!! Vous avez gagné la partie")
    else:
        print("Domage. Vous avez perdu")
        afficher_reussite(liste_tas)
    return liste_tas
        xinit = xinit + largeur_carte + separation


