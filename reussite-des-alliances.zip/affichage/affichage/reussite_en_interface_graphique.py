#!/usr/bin/env python3
import random
from random import choice
from turtle import *

def init_pioche_alea(nb_cartes=32):
    liste_32_cartes=[{"valeur":7, "couleur":"T"}, {"valeur":8, "couleur":"T"}, {"valeur":9, "couleur":"T"}, {"valeur":10, "couleur":"T"}, {"valeur":"V", "couleur":"T"},{"valeur":"D", "couleur":"T"}, {"valeur":"R", "couleur":"T"}, {"valeur":"A", "couleur":"T"}, {"valeur":7, "couleur":"P"}, {"valeur":8, "couleur":"P"}, {"valeur":9, "couleur":"P"}, {"valeur":10, "couleur":"P"}, {"valeur":"V", "couleur":"P"},{"valeur":"D", "couleur":"P"}, {"valeur":"R", "couleur":"P"}, {"valeur":"A", "couleur":"P"}, {"valeur":7, "couleur":"C"}, {"valeur":8, "couleur":"C"},{"valeur":9, "couleur":"C"}, {"valeur":10, "couleur":"C"}, {"valeur":"V", "couleur":"C"},{"valeur":"D", "couleur":"C"}, {"valeur":"R", "couleur":"C"}, {"valeur":"A", "couleur":"C"}, {"valeur":7, "couleur":"K"}, {"valeur":8, "couleur":"K"}, {"valeur":9, "couleur":"K"}, {"valeur":10, "couleur":"K"}, {"valeur":"V", "couleur":"K"},{"valeur":"D", "couleur":"K"}, {"valeur":"R", "couleur":"K"}, {"valeur":"A", "couleur":"K"}]
    liste_52_cartes=[{"valeur":2, "couleur":"T"}, {"valeur":3, "couleur":"T"}, {"valeur":4, "couleur":"T"}, {"valeur":5, "couleur":"T"}, {"valeur":6, "couleur":"T"}, {"valeur":7, "couleur":"T"}, {"valeur":8, "couleur":"T"}, {"valeur":9, "couleur":"T"}, {"valeur":10, "couleur":"T"}, {"valeur":"V", "couleur":"T"},{"valeur":"D", "couleur":"T"}, {"valeur":"R", "couleur":"T"}, {"valeur":"A", "couleur":"T"}, {"valeur":2, "couleur":"P"}, {"valeur":3, "couleur":"P"}, {"valeur":4, "couleur":"P"}, {"valeur":5, "couleur":"P"}, {"valeur":6, "couleur":"P"}, {"valeur":7, "couleur":"P"}, {"valeur":8, "couleur":"P"}, {"valeur":9, "couleur":"P"}, {"valeur":10, "couleur":"P"}, {"valeur":"V", "couleur":"P"},{"valeur":"D", "couleur":"P"}, {"valeur":"R", "couleur":"P"}, {"valeur":"A", "couleur":"P"}, {"valeur":2, "couleur":"C"}, {"valeur":3, "couleur":"C"}, {"valeur":4, "couleur":"C"}, {"valeur":5, "couleur":"C"}, {"valeur":6, "couleur":"C"}, {"valeur":7, "couleur":"C"}, {"valeur":8, "couleur":"C"},{"valeur":9, "couleur":"C"}, {"valeur":10, "couleur":"C"}, {"valeur":"V", "couleur":"C"},{"valeur":"D", "couleur":"C"}, {"valeur":"R", "couleur":"C"}, {"valeur":"A", "couleur":"C"}, {"valeur":2, "couleur":"K"}, {"valeur":3, "couleur":"K"}, {"valeur":4, "couleur":"K"}, {"valeur":5, "couleur":"K"}, {"valeur":6, "couleur":"K"}, {"valeur":7, "couleur":"K"}, {"valeur":8, "couleur":"K"}, {"valeur":9, "couleur":"K"}, {"valeur":10, "couleur":"K"}, {"valeur":"V", "couleur":"K"},{"valeur":"D", "couleur":"K"}, {"valeur":"R", "couleur":"K"}, {"valeur":"A", "couleur":"K"}]            
    if nb_cartes==32:
        random.shuffle(liste_32_cartes)
        return liste_32_cartes
    if nb_cartes==52:
        liste=random.shuffle(liste_52_cartes)
        return liste_52_cartes

def alliance(carte1, carte2):
    alliances=False
    if carte1['valeur']==carte2['valeur'] or carte1['couleur']==carte2['couleur']:
        return True
    return alliances

def saut_si_possible(liste_tas, num_tas):                         
    saut=False
    if 1 <= num_tas <= len(liste_tas)-2: # Par prudence précisons que num_tas doit etre au minimum égale au troisième element de la liste
                                                                    # pour qu'on puisse parler de réussite
        if alliance(liste_tas[num_tas-1], liste_tas[num_tas+1]):
            liste_tas.pop(num_tas-1) 
            saut=True
    return saut
        
def saut_si_possible_version2(liste_tas, num_tas):                         
    saut=False
    if 1 <= num_tas <= len(liste_tas)-2:                                                                  
        if alliance(liste_tas[num_tas-1], liste_tas[num_tas+1]):
            saut=True
    return saut

def autre_saut_si_possible_version2(liste_tas):
    n=len(liste_tas)                                            
    j=0
    i=0
    liste=[]
    while i < 2*n :
        while j < len(liste_tas):                                  
            if saut_si_possible(liste_tas, j) :                  
                liste.append(j)
                j = -1
            j += 1
        j = 0
        i += 1
    return liste

def reussite_mode_auto_en_interface_graphique(liste_carte):
    fenetre = Screen()  # la fenetre d'affichage
    setup(width=1366, height=768, startx=0, starty=0)
    title("La reussite des alliances")
    bgpic("bg.gif")
    bgcolor("green")
    
    valeurs=[]
    couleurs=[]
    
    for carte in liste_carte:
        valeurs.append(str(carte["valeur"]))
        couleurs.append(carte["couleur"])
    
    carte = {}
    for c in couleurs:
        for v in valeurs:
            fichier = "imgs/carte-" + v + '-' + c + '.gif'
            carte[c, v] = fichier
            fenetre.register_shape( fichier ) # nouvelle forme pour le pointeur

    # On charge aussi l'image du dos des cartes
    dos = "imgs/carte-dos.gif"
    fenetre.register_shape( dos )
    # coordonnées de démarrage

    xinit = -650
    yinit =  200

    largeur_carte = 44
    hauteur_carte = 64
    separation = 5      # espace à laisser entre les cartes



    up()          # on ne trace pas les déplacement
    speed(3)      # changer la vitesse d'affichage 0-10

    tampons = {}  # dictionnaire pour se souvenir où on a placé les cartes

    pioche=list(liste_carte)
    liste_tas=[]
    
    while pioche != []:
        liste_tas.append(pioche[0])
        pioche.pop(0)
        elem=liste_tas[-1]
        
        shape( dos )

        goto(xinit,yinit)
        c=elem["couleur"]
        v=str(elem["valeur"])
        shape( carte[ c, v] )
        tampons[c, v]=stamp()

        num_tas=len(liste_tas)-2
        if saut_si_possible_version2(liste_tas, num_tas):
            
            elem=liste_tas[num_tas-1]
            c=elem["couleur"]
            v=str(elem["valeur"])
            clearstamp (tampons[c, v])
            tampons.pop ((c, v))
            tas_a_supprimer=num_tas-1
            liste_tas.pop(num_tas-1)
            
              
            clearstamps(-2) # on fait sauter la carte d'indice num_tas et on décale toutes situant à sa droite ers la gauche
            
           
            xinit=xprecedent - largeur_carte - separation
            yinit=yprecedent

            if tas_a_supprimer == 26:
                yinit = yprecedent + hauteur_carte + separation
                xinit=xperso 
                
            
            for i in range(num_tas-1, len(liste_tas)):
                shape( dos )
                elem1=liste_tas[i]
                c1=elem1["couleur"]
                v1=str(elem1["valeur"])
                goto(xinit,yinit)
                shape( carte[ c1, v1] )
                tampons[c1, v1]=stamp()

                if i != len(liste_tas)-1:                
                    xinit = xinit + largeur_carte + separation

                if xinit > 650:  
                    xinit=-650
                    yinit = yinit - hauteur_carte - separation

            
        # Verifions si d'autres sauts sont possibles
            
            copi_liste_tas = list(liste_tas)           # pour eviter que la fonction autre saut si possible modifient ma liste_tas
            liste_tas_a_sauter=autre_saut_si_possible_version2(copi_liste_tas)
            
            if liste_tas_a_sauter != []:
                
                for num_tas in liste_tas_a_sauter:
                    
                    if saut_si_possible_version2(liste_tas, num_tas):
            
                        elem=liste_tas[num_tas-1]
                        c=elem["couleur"]
                        v=str(elem["valeur"])
                        clearstamp (tampons[c, v])
                        tampons.pop ((c, v))
                        tas_a_supprimer=num_tas-1
                        liste_tas.pop(num_tas-1)
                        
                        clearstamps(-(len(liste_tas)-num_tas+1)) #-3 on fait sauter la carte d'indice num_tas et on décale toutes situant à sa droite ers la gauche

                        if tas_a_supprimer == 26 :
                            yinit=yinit + hauteur_carte + separation
                            
                        if num_tas > 26:
                            num_tas=num_tas-26
                            
                        xinit=xinit -(len(liste_tas)-num_tas+1)*largeur_carte -(len(liste_tas)-num_tas+1)*separation

                        for i in range(num_tas-1, len(liste_tas)):
                            shape( dos )
                            elem1=liste_tas[i]
                            c1=elem1["couleur"]
                            v1=str(elem1["valeur"])
                            goto(xinit,yinit)
                            shape( carte[ c1, v1] )
                            tampons[c1, v1]=stamp()
                    
                            if i != len(liste_tas)-1:                
                                xinit = xinit + largeur_carte + separation
                
            liste_tas_a_sauter=[]
                  
       
        xprecedent=xinit
        yprecedent=yinit

        if num_tas == 25:
            xperso=xinit
        
        xinit = xinit + largeur_carte + separation
        
        if xinit > 650:
            xinit=-650
            yinit = yinit - hauteur_carte - separation

    hideturtle()    
    goto(0, 0)
    write("CLIQUER DANS LA FENETRE POUR TERMINER ", align='center')
    exitonclick()
    
