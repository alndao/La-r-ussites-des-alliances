import random

def init_pioche_alea(nb_cartes=32):
    liste_32_cartes=[{"valeur":7, "couleur":"T"}, {"valeur":8, "couleur":"T"}, {"valeur":9, "couleur":"T"}, {"valeur":10, "couleur":"T"}, {"valeur":"V", "couleur":"T"},{"valeur":"D", "couleur":"T"}, {"valeur":"R", "couleur":"T"}, {"valeur":"A", "couleur":"T"}, {"valeur":7, "couleur":"P"}, {"valeur":8, "couleur":"P"}, {"valeur":9, "couleur":"P"}, {"valeur":10, "couleur":"P"}, {"valeur":"V", "couleur":"P"},{"valeur":"D", "couleur":"P"}, {"valeur":"R", "couleur":"P"}, {"valeur":"A", "couleur":"P"}, {"valeur":7, "couleur":"C"}, {"valeur":8, "couleur":"C"},{"valeur":9, "couleur":"C"}, {"valeur":10, "couleur":"C"}, {"valeur":"V", "couleur":"C"},{"valeur":"D", "couleur":"C"}, {"valeur":"R", "couleur":"C"}, {"valeur":"A", "couleur":"C"}, {"valeur":7, "couleur":"K"}, {"valeur":8, "couleur":"K"}, {"valeur":9, "couleur":"K"}, {"valeur":10, "couleur":"K"}, {"valeur":"V", "couleur":"K"},{"valeur":"D", "couleur":"K"}, {"valeur":"R", "couleur":"K"}, {"valeur":"A", "couleur":"K"}]
    liste_52_cartes=[{"valeur":2, "couleur":"T"}, {"valeur":3, "couleur":"T"}, {"valeur":4, "couleur":"T"}, {"valeur":5, "couleur":"T"}, {"valeur":6, "couleur":"T"}, {"valeur":7, "couleur":"T"}, {"valeur":8, "couleur":"T"}, {"valeur":9, "couleur":"T"}, {"valeur":10, "couleur":"T"}, {"valeur":"V", "couleur":"T"},{"valeur":"D", "couleur":"T"}, {"valeur":"R", "couleur":"T"}, {"valeur":"A", "couleur":"T"}, {"valeur":2, "couleur":"P"}, {"valeur":3, "couleur":"P"}, {"valeur":4, "couleur":"P"}, {"valeur":5, "couleur":"P"}, {"valeur":6, "couleur":"P"}, {"valeur":7, "couleur":"P"}, {"valeur":8, "couleur":"P"}, {"valeur":9, "couleur":"P"}, {"valeur":10, "couleur":"P"}, {"valeur":"V", "couleur":"P"},{"valeur":"D", "couleur":"P"}, {"valeur":"R", "couleur":"P"}, {"valeur":"A", "couleur":"P"}, {"valeur":2, "couleur":"C"}, {"valeur":3, "couleur":"C"}, {"valeur":4, "couleur":"C"}, {"valeur":5, "couleur":"C"}, {"valeur":6, "couleur":"C"}, {"valeur":7, "couleur":"C"}, {"valeur":8, "couleur":"C"},{"valeur":9, "couleur":"C"}, {"valeur":10, "couleur":"C"}, {"valeur":"V", "couleur":"C"},{"valeur":"D", "couleur":"C"}, {"valeur":"R", "couleur":"C"}, {"valeur":"A", "couleur":"C"}, {"valeur":2, "couleur":"K"}, {"valeur":3, "couleur":"K"}, {"valeur":4, "couleur":"K"}, {"valeur":5, "couleur":"K"}, {"valeur":6, "couleur":"K"}, {"valeur":7, "couleur":"K"}, {"valeur":8, "couleur":"K"}, {"valeur":9, "couleur":"K"}, {"valeur":10, "couleur":"K"}, {"valeur":"V", "couleur":"K"},{"valeur":"D", "couleur":"K"}, {"valeur":"R", "couleur":"K"}, {"valeur":"A", "couleur":"K"}]            
    if nb_cartes==32:
        random.shuffle(liste_32_cartes)
        return liste_32_cartes
    if nb_cartes==52:
        liste=random.shuffle(liste_52_cartes)
        return liste_52_cartes
        
#partie4
def alliance(carte1, carte2):
    alliances=False
    if carte1['valeur']==carte2['valeur'] or carte1['couleur']==carte2['couleur']:
        return True
    return alliances


carte1={"valeur":7, "couleur":"P"}
carte2={"valeur":8, "couleur":"C"}

def saut_si_possible(liste_tas, num_tas):                         
    saut=False
    if 1 <= num_tas <= len(liste_tas)-2: # Par prudence précisons que num_tas doit etre au minimum égale au troisième element de la liste
                                                                    # pour qu'on puisse parler de réussite
        if alliance(liste_tas[num_tas-1], liste_tas[num_tas+1]):
            liste_tas.pop(num_tas-1) 
            saut=True
    return saut

def autre_saut_si_possible(liste_tas, affiche1=False):
    n=len(liste_tas)                                            # fonction auxilière qui prend en argument une liste de tas et un bouléen valant False par defaut
    j=0
    i=0
    while i < 2*n :
        while j < len(liste_tas):                                  # cette fonction vérifie si un saut est possible dans la liste de tas
            if saut_si_possible(liste_tas, j) :                 # si le saut est possible la fonction l'effectue 
                if affiche1:                                  # a chaque saut la fonction affiche l'etape de la réussite si affiche vaut True.
                    afficher_reussite(liste_tas)
                j = -1
            j += 1
        j = 0
        i += 1

def saut_si_possible_version2(liste_tas, num_tas):                         
    saut=False
    if 1 <= num_tas <= len(liste_tas)-2:                                                                  
        if alliance(liste_tas[num_tas-1], liste_tas[num_tas+1]):
            saut=True
    return saut

def autre_saut_si_possible_version2(liste_tas):
    n=len(liste_tas)                                            
    j=0
    i=0
    liste=[]
    while i < 2*n :
        while j < len(liste_tas):                                  
            if saut_si_possible(liste_tas, j) :                  
                liste.append(j)
                j = -1
            j += 1
        j = 0
        i += 1
    return liste

from turtle import *

def reussite_mode_manuel_en_interface_graphique(pioche, nb_tas_max=2):
    fenetre = Screen()  # la fenetre d'affichage
    setup(width=1366, height=768, startx=0, starty=0)
    title("La reussite des alliances")
    bgcolor("green")
    # charger les images de toutes les cartes de la pioche
    valeurs=[]
    couleurs=[]
    
    for carte in pioche:
        valeurs.append(str(carte["valeur"]))
        couleurs.append(carte["couleur"])
    
    carte = {}
    for c in couleurs:
        for v in valeurs:
            fichier = "imgs/carte-" + v + '-' + c + '.gif'
            carte[c, v] = fichier
            fenetre.register_shape( fichier ) # nouvelle forme pour le pointeur

    # On charge aussi l'image du dos des cartes
    dos = "imgs/carte-dos.gif"
    fenetre.register_shape( dos )
    # coordonnées de démarrage

    xinit = -650
    yinit =  200

    largeur_carte = 44
    hauteur_carte = 64
    separation = 5      # espace à laisser entre les cartes



    up()          # on ne trace pas les déplacement
    speed(3)      # changer la vitesse d'affichage 0-10

    tampons = {}  # dictionnaire pour se souvenir où on a placé les cartes

    copi_pioche=list(pioche)
    liste_tas=[]
    for i in range(3):
        liste_tas.append(copi_pioche[0])
        copi_pioche.pop(0)
        elem=liste_tas[-1]
        
        shape( dos )

        goto(xinit,yinit)
        c=elem["couleur"]
        v=str(elem["valeur"])
        shape( carte[ c, v] )
        tampons[c, v]=stamp()

        xinit = xinit + largeur_carte + separation
        #hideturtle()
    
    xprecedent=xinit
    yprecedent=yinit
    listen()
    while copi_pioche != []:
            
        choix=textinput("C'est à vous de joueur", "Que voulez-vous faire")

        if choix == "p":
            if xinit > 650:  
                xinit=-650
                yinit = yinit - hauteur_carte - separation 
            liste_tas.append(copi_pioche[0])
            copi_pioche.pop(0)
            elem=liste_tas[-1]
            shape( dos )
            goto(xinit,yinit)
            c=elem["couleur"]
            v=str(elem["valeur"])
            shape( carte[ c, v] )
            tampons[c, v]=stamp()
            
        elif choix == "q":
            if xinit > 650:  
                xinit=-650
                yinit = yinit - hauteur_carte - separation
                    
            for i in range(len(copi_pioche)): 
                liste_tas.append(copi_pioche[0])
                     
                copi_pioche.pop(0)
                elem=liste_tas[-1]
        
                shape( dos )

                goto(xinit,yinit)
                c=elem["couleur"]
                v=str(elem["valeur"])
                shape( carte[ c, v] )
                tampons[c, v]=stamp()

                xinit = xinit + largeur_carte + separation
                if xinit > 650:  
                    xinit=-650
                    yinit = yinit - hauteur_carte - separation

        elif choix == "s":
            num_tas=int(numinput("C'est à vous de jouer", "Quel est le tas à faire sauter"))
            if saut_si_possible_version2(liste_tas, num_tas):
                elem=liste_tas[num_tas-1]
                c=elem["couleur"]
                v=str(elem["valeur"])
                clearstamp (tampons[c, v])
                tampons.pop ((c, v))
                tas_a_supprimer=num_tas-1
                liste_tas.pop(num_tas-1)
                    
                clearstamps(-(len(liste_tas)-num_tas+1))
                
                if tas_a_supprimer == 26 :
                    yinit=yinit + hauteur_carte + separation
                            
                if num_tas > 26:
                    num_tas=num_tas-26
                            
                xinit=xinit - (len(liste_tas)-num_tas+2)*largeur_carte -(len(liste_tas)-num_tas+2)*separation
               

                for i in range(num_tas-1, len(liste_tas)):
                    shape( dos )
                    elem1=liste_tas[i]
                    c1=elem1["couleur"]
                    v1=str(elem1["valeur"])
                    goto(xinit,yinit)
                    shape( carte[ c1, v1] )
                    tampons[c1, v1]=stamp()
                    
                    if i != len(liste_tas)-1:                
                        xinit = xinit + largeur_carte + separation
            else:
                hideturtle()
                goto(0,0)
                write("OUPS! LE SAUT N4EST PAS POSSIBLE")
                xinit = xinit - largeur_carte - separation
                
                        
        xprecedent=xinit
        yprecedent=yinit

        xinit = xinit + largeur_carte + separation
        
        if xinit > 650:
            xinit=-650
            yinit = yinit - hauteur_carte - separation

        
    if len(liste_tas) <= nb_tas_max:
        hideturtle()
        goto(0,0)
        write("BRAVO! VOUS AVEZ GAGNE LA PARTIE.", align="center")
    else:
        hideturtle()
        goto(0,0)
        write("DOMAGE! VOUS AVEZ PERDU.", align="center")
    goto(-30, -30)
    write("CLIQUER DANS LA FENETRE POUR TERMINER ", align="center")
    exitonclick()
       
  
