from reussite_mode_manuel_en_interface_graphique import *
from reussite_en_interface_graphique import *

def lance_reussite_en_interface_graphique():
    setup(width=1366, height=768, startx=0, starty=0)
    title("La reussite des alliances")
    bgcolor("green")
    bgpic("bg.gif")
    nb_cartes=int(numinput("Parametres du jeu", "Nombre de cartes"))
    mode=textinput("Parametre du jeu", "Mode")
    pioche=init_pioche_alea(nb_cartes=nb_cartes) 
    if mode == "manuel":
        nb_tas_max=int(numinput("Parametres du jeu", "Nombre de tas max"))
        reussite_mode_manuel_en_interface_graphique(pioche, nb_tas_max=2)
    elif mode == "auto":
        reussite_mode_auto_en_interface_graphique(pioche)
        
    
lance_reussite_en_interface_graphique()
