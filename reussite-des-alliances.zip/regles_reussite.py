def alliance(carte1, carte2):
    alliances=False
    if carte1['valeur']==carte2['valeur'] or carte1['couleur']==carte2['couleur']:
        return True
    return alliances


carte1={"valeur":7, "couleur":"P"}
carte2={"valeur":8, "couleur":"C"}

#print(alliance(cate1, carte2))


def saut_si_possible(liste_tas, num_tas):                         
    saut=False
    if 1 <= num_tas <= len(liste_tas)-2: # Par prudence précisons que num_tas doit etre au minimum égale au troisième element de la liste
                                                                    # pour qu'on puisse parler de réussite
        if alliance(liste_tas[num_tas-1], liste_tas[num_tas+1]):
            liste_tas.pop(num_tas-1) 
            saut=True
    return saut


#liste=[{"valeur":7, "couleur":"T"}, {"valeur":8, "couleur":"P"}, {"valeur":7, "couleur":"C"}]
#print(saut_si_possible(liste, 1))

def autre_saut_si_possible(liste_tas, affiche1=False):
    n=len(liste_tas)                                            # fonction auxilière qui prend en argument une liste de tas et un bouléen valant False par defaut
    j=0
    i=0
    while i < 2*n :
        while j < len(liste_tas):                                  # cette fonction vérifie si un saut est possible dans la liste de tas
            if saut_si_possible(liste_tas, j) :                 # si le saut est possible la fonction l'effectue 
                if affiche1:                                  # a chaque saut la fonction affiche l'etape de la réussite si affiche vaut True.
                    afficher_reussite(liste_tas)
                j = -1
            j += 1
        j = 0
        i += 1
    
liste_tas=[{"valeur":10, "couleur":"P"}, {"valeur":7, "couleur":"K"}, {"valeur":"D", "couleur":"P"}, {"valeur":7, "couleur":"K"}, {"valeur":8, "couleur":"P"}]
#autre_saut_si_possible(liste_tas)

def une_etape_reussite(liste_tas, pioche, affiche=False):
    liste_tas.append(pioche[0])
    if affiche:
        afficher_reussite(liste_tas)
    pioche.pop(0)
    num_tas=len(liste_tas)-2
    if saut_si_possible(liste_tas, num_tas):
        if affiche:
            afficher_reussite(liste_tas)
        autre_saut_si_possible(liste_tas, affiche1=affiche)    



