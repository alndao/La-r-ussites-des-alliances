from verifier_pioche.py import *

def res_multi_simulation(nb_sim, nb_cartes=32):
    liste_nombre_tas=[]
    for i in range(nb_sim):
        if nb_cartes==32:
            pioche=init_pioche_alea()
        elif nb_cartes==52:
            pioche=inti_pioche_alea(nb_cartes=52)
        liste_tas_finale=reussite_mode_auto(pioche, affiche=False)
        liste_nombre_tas.append(len(liste_tas_finale))
    return liste_nombre_tas

def statistiques_nb_tas(nb_sim, nb_cartes=32):
    liste_nombre_tas=res_multi_simulation(nb_sim, nb_cartes=nb_cartes)
    maxi=liste_nombre_tas[0]
    mini=liste_nombre_tas[0]
    somme=0
    for i in range(1, len(liste_nombre_tas)):
        if maxi < liste_nombre_tas[i]:
            maxi=liste_nombre_tas[i]
        if mini > liste_nombre_tas[i]:
            mini=liste_nombre_tas[i]
        somme += liste_nombre_tas[i]
    print("La moyenne des tas obtenu sur", nb_sim, "reussites automatiques est: ",somme/(len(liste_nombre_tas)))
    print("Le nombre de tas minimum sur", nb_sim, "reussites automatiques est: ", mini)
    print("Le nombre de tas maximum sur", nb_sim, "reussites automatiques est: ", maxi)

#statistiques_nb_tas(3, nb_cartes=32)

def estim_Probabilite(nb_sim, nb_cartes=32):
    listes_des_proba=[]
    for j in range(nb_sim):
        nb_tas_max=2
        liste=res_multi_simulation(nb_sim, nb_cartes=nb_sartes)
        frequence=0
        for i in range(len(liste)):
            if nb_tas_max==liste[i]:
                frequence += 1
        proba=frequence/(len(liste))
        listes_des_proba.append(proba)
        nb_tas_max += 1
    return listes_des_proba


import numpy as np
import matplotlib as plt
print(estim_Probabilite(30, nb_cartes=32))

liste=[0.06666666666666667, 0.03333333333333333, 0.06666666666666667, 0.06666666666666667, 0.2, 0.3333333333333333, 0.26666666666666666, 0.2, 0.3333333333333333, 0.5, 0.7, 0.7333333333333333, 0.8, 0.8666666666666667, 0.7666666666666667, 0.8333333333333334, 0.8333333333333334, 0.9333333333333333, 0.8666666666666667, 0.8666666666666667, 1.0, 0.9666666666666667, 1.0, 0.9666666666666667, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0]

# on tracer la coubre avec la liste des probalite retourner par la fonction estim_Probabilite

import numpy as np
import matplotlib.pyplot as plt

x=np.linspace(2, 32, 30)

y=(liste)

plt.xlabel("Axe representant le  nombre de tas maximal")
plt.ylabel("Axe representant la probalite ")
plt.title("Courbe repesentant la probabilite de gagner une partie en fonction nombre de tas maximal")
plt.grid()
plt.plot(x,y, 'go:')
plt.show()

