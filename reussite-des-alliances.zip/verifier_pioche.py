def verifier_pioche(pioche, nb_cartes=32):
    if len(pioche) != nb_cartes:
        return False
    else:
        for i in range(nb_cartes):
            for j in range(i+1, nb_cartes):
                if nb_cartes==32:
                    if pioche[j]["valeur"]==2 or pioche[j]["valeur"]==3 or pioche[j]["valeur"]==4 or pioche[j]["valeur"]==5 or pioche[j]["valeur"]==6 :
                        return False
                if pioche[i]==pioche[j]:
                    return False
    return True

        
